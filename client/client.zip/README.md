# Client

To start the development server: 

```
cd client
npm install
npm run dev 
```